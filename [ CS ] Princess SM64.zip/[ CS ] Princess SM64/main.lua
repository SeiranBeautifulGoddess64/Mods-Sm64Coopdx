-- name: [CS] \\#ff99cc\\Super \\#ff5588\\Princess \\#ff33cc\\Characters \\#ff0065\\64
-- description: [CS] Princess Characters SM64\nBy Coop Deluxe Team\n\nThis Character Select pack adds other characters from the Mario series!
--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/blob/main/API-doc.md
]]

local E_MODEL_DAISY = smlua_model_util_get_id("daisy_geo")
local E_MODEL_PEACH_PLAYER = smlua_model_util_get_id("peach_player_geo")
local E_MODEL_TOADETTE = smlua_model_util_get_id("toadette_geo")
local E_MODEL_YOSHI_PLAYER = smlua_model_util_get_id("yoshi_player_geo")
local TEX_DAISY_ICON = get_texture_info("daisy_icon")
local TEX_PEACH_PLAYER_ICON = get_texture_info("peach_player_icon")
local TEX_TOADETTE_ICON = get_texture_info("toadette_icon")
local TEX_YOSHI_PLAYER_ICON = get_texture_info("yoshi-icon")

local TEXT_MOD_NAME = "Super Princess SM64"
--
local VOICETABLE_DAISY = {
    [CHAR_SOUND_ATTACKED] = {'daisy_attacked_1.ogg','daisy_attacked_2.ogg','daisy_attacked_3.ogg'},
    [CHAR_SOUND_COUGHING1] = 'daisy_coughing1.ogg',
    [CHAR_SOUND_COUGHING2] = 'daisy_coughing2.ogg',
    [CHAR_SOUND_COUGHING3] = 'daisy_coughing3.ogg',
    [CHAR_SOUND_DOH] = {'daisy_doh_1.ogg', 'daisy_doh_2.ogg'},
    [CHAR_SOUND_DROWNING] = 'daisy_drowning_1.ogg',
    [CHAR_SOUND_DYING] = 'daisy_dying.ogg',
    [CHAR_SOUND_EEUH] = 'daisy_eeuh.ogg',
    [CHAR_SOUND_GROUND_POUND_WAH] = 'daisy_ground_pound_wah.ogg',
    [CHAR_SOUND_HAHA] = 'daisy_haha.ogg',
    [CHAR_SOUND_HAHA_2] = 'daisy_haha_2.ogg',
    [CHAR_SOUND_HERE_WE_GO] = 'daisy_here_we_go.ogg',
    [CHAR_SOUND_HOOHOO] = 'daisy_hoohoo.ogg',
    [CHAR_SOUND_HRMM] = 'daisy_hrmm.ogg',
    [CHAR_SOUND_IMA_TIRED] = 'daisy_ima_tired.ogg',
    [CHAR_SOUND_MAMA_MIA] = 'daisy_mama_mia.ogg',
    [CHAR_SOUND_LETS_A_GO] = 'daisy_lets_a_go.ogg',
    [CHAR_SOUND_ON_FIRE] = 'daisy_on_fire.ogg',
    [CHAR_SOUND_OOOF] = 'daisy_oof.ogg',
    [CHAR_SOUND_OOOF2] = 'daisy_ooof2.ogg',
    [CHAR_SOUND_PANTING] = 'daisy_panting.ogg',
    [CHAR_SOUND_PANTING_COLD] = 'daisy_panting_cold.ogg',
    [CHAR_SOUND_PUNCH_HOO] = 'daisy_punch_hoo.ogg',
    [CHAR_SOUND_PUNCH_WAH] = 'daisy_punch_wah.ogg',
    [CHAR_SOUND_PUNCH_YAH] = 'daisy_punch_yah.ogg',
    [CHAR_SOUND_SO_LONGA_BOWSER] = 'daisy_so_longa_bowser.ogg',
    [CHAR_SOUND_SNORING1] = 'daisy_snoring1.ogg',
    [CHAR_SOUND_SNORING2] = 'daisy_snoring2.ogg',
    [CHAR_SOUND_SNORING3] = {'daisy_snoring2.ogg', 'daisy_snoring1.ogg', 'daisy_snoring3.ogg'},
    [CHAR_SOUND_TWIRL_BOUNCE] = 'daisy_twirl_bounce.ogg',
    [CHAR_SOUND_UH] = 'daisy_uh.ogg',
    [CHAR_SOUND_UH2] = 'daisy_uh2.ogg',
    [CHAR_SOUND_UH2_2] = 'daisy_uh2_2.ogg',
    [CHAR_SOUND_WAAAOOOW] = 'daisy_waaaooow.ogg',
    [CHAR_SOUND_WAH2] = 'daisy_wah2.ogg',
    [CHAR_SOUND_WHOA] = 'daisy_whoa.ogg',
    [CHAR_SOUND_YAHOO] = 'daisy_yahoo.ogg',
    [CHAR_SOUND_YAWNING] = 'daisy_yawning.ogg',
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = { 'daisy_yahoo.ogg', 'daisy_yahoo2.ogg', 'daisy_yahoo3.ogg', 'daisy_yahoo4.ogg'},
    [CHAR_SOUND_YAH_WAH_HOO] = { 'daisy_yah1.ogg', 'daisy_yah2.ogg', 'daisy_yah3.ogg'},
    [CHAR_SOUND_HELLO] = 'daisy_double_jump.ogg'
}

local VOICETABLE_PEACH_PLAYER = {
    [CHAR_SOUND_ATTACKED] = "peach_attacked.ogg",
    [CHAR_SOUND_COUGHING1] = "peach_coughing1.ogg",
    [CHAR_SOUND_COUGHING2] = "peach_coughing2.ogg",
    [CHAR_SOUND_COUGHING3] = "peach_coughing3.ogg",
    [CHAR_SOUND_DOH] = "peach_doh.ogg",
    [CHAR_SOUND_DROWNING] = "peach_drowning.ogg",
    [CHAR_SOUND_DYING] = "peach_dying.ogg",
    [CHAR_SOUND_EEUH] = "peach_euuh.ogg",
    [CHAR_SOUND_GROUND_POUND_WAH] = "peach_ground_pound_wah.ogg",
    [CHAR_SOUND_HAHA] = "peach_haha.ogg",
    [CHAR_SOUND_HAHA_2] = "peach_haha.ogg",
    [CHAR_SOUND_HERE_WE_GO] = "peach_herewego.ogg",
    [CHAR_SOUND_HOOHOO] = "peach_hoohoo.ogg",
    [CHAR_SOUND_HRMM] = "peach_hrmm.ogg",
    [CHAR_SOUND_IMA_TIRED] = "peach_imatired.ogg",
    [CHAR_SOUND_MAMA_MIA] = "peach_mamamia.ogg",
    [CHAR_SOUND_LETS_A_GO] = "peach_letsago.ogg",
    [CHAR_SOUND_ON_FIRE] = "peach_on_fire.ogg",
    [CHAR_SOUND_OOOF] = "peach_ooof.ogg",
    [CHAR_SOUND_OOOF2] = "peach_ooof2.ogg",
    [CHAR_SOUND_PANTING] = "peach_panting.ogg",
    [CHAR_SOUND_PANTING_COLD] = "peach_panting_cold.ogg",
    [CHAR_SOUND_PUNCH_HOO] = "peach_punch_hoo.ogg",
    [CHAR_SOUND_PUNCH_WAH] = "peach_punch_wah.ogg",
    [CHAR_SOUND_PUNCH_YAH] = "peach_punch_yah.ogg",
    [CHAR_SOUND_SO_LONGA_BOWSER] = "peach_solonga_bowser.ogg",
    [CHAR_SOUND_SNORING1] = "peach_snoring1.ogg",
    [CHAR_SOUND_SNORING2] = "peach_snoring2.ogg",
    [CHAR_SOUND_SNORING3] = {"peach_snoring2.ogg", "peach_snoring1.ogg", "peach_snoring3.ogg"},
    [CHAR_SOUND_TWIRL_BOUNCE] = "peach_twirl_bounce.ogg",
    [CHAR_SOUND_UH] = "peach_uh.ogg",
    [CHAR_SOUND_UH2] = "peach_uh2.ogg",
    [CHAR_SOUND_UH2_2] = "peach_uh2_2.ogg",
    [CHAR_SOUND_WAAAOOOW] = "peach_waaaooow.ogg",
    [CHAR_SOUND_WAH2] = "peach_ground_pound_wah.ogg",
    [CHAR_SOUND_WHOA] = "peach_whoa.ogg",
    [CHAR_SOUND_YAHOO] = "peach_yahoo.ogg",
    [CHAR_SOUND_YAWNING] = "peach_yawning.ogg",
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = { "peach_yahoo.ogg", "peach_yahoo1.ogg", "peach_yahoo2.ogg", "peach_yahoo3.ogg", "peach_yahoo4.ogg", "peach_yahoo5.ogg" },
    [CHAR_SOUND_YAH_WAH_HOO] = { "peach_yah_wah_hoo1.ogg", "peach_yah_wah_hoo2.ogg", "peach_yah_wha_hoo3.ogg"},
    [CHAR_SOUND_HELLO] = "peach_float.ogg"
}

local VOICETABLE_TOADETTE = {
    [CHAR_SOUND_ATTACKED] = "toadette_hurt_hard.ogg",
    [CHAR_SOUND_GROUND_POUND_WAH] = "toadette_yah.ogg",
    [CHAR_SOUND_HAHA] = "toadette_haahaa.ogg",
    [CHAR_SOUND_HAHA_2] = "toadette_haahaa.ogg",
    [CHAR_SOUND_HERE_WE_GO] = "toadette_here_we_go.ogg",
    [CHAR_SOUND_HOOHOO] = "toadette_hoo.ogg",
    [CHAR_SOUND_ON_FIRE] = "toadette_burning.ogg",
    [CHAR_SOUND_OOOF] = "toadette_oof.ogg",
    [CHAR_SOUND_OOOF2] = "toadette_oof2.ogg",
    [CHAR_SOUND_PUNCH_HOO] = "toadette_hoo.ogg",
    [CHAR_SOUND_PUNCH_WAH] = "toadette_wah.ogg",
    [CHAR_SOUND_PUNCH_YAH] = "toadette_yah.ogg",
    [CHAR_SOUND_SO_LONGA_BOWSER] = "toadette_bowser.ogg",
    [CHAR_SOUND_TWIRL_BOUNCE] = "toadette_boing.ogg",
    [CHAR_SOUND_WAAAOOOW] = "toadette_fall.ogg",
    [CHAR_SOUND_WAH2] = "toadette_wah.ogg",
    [CHAR_SOUND_WHOA] = "toadette_woah.ogg",
    [CHAR_SOUND_YAHOO] = "toadette_yahoo.ogg",
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {"toadette_yahoo.ogg", "toadette_yippee.ogg"},
    [CHAR_SOUND_YAH_WAH_HOO] = {"toadette_yah.ogg", "toadette_wah.ogg", "toadette_hoo.ogg"},
    [CHAR_SOUND_OKEY_DOKEY] = "toadette_okay.ogg",
    [CHAR_SOUND_LETS_A_GO] = "toadette_okay.ogg",
    [CHAR_SOUND_DYING] = "toadette_dead.ogg",
    [CHAR_SOUND_DROWNING] = "toadette_drowning.ogg",
    [CHAR_SOUND_EEUH] = "toadette_pickup.ogg",
    [CHAR_SOUND_MAMA_MIA] = "toadette_ooh.ogg",
    [CHAR_SOUND_DOH] = "toadette_oof.ogg",
    [CHAR_SOUND_HRMM] = "toadette_pickup.ogg",
    [CHAR_SOUND_PANTING] = "toadette_pant.ogg",
    [CHAR_SOUND_UH] = "toadette_oof2.ogg",
    [CHAR_SOUND_UH2] = "toadette_oof2.ogg",
    [CHAR_SOUND_UH2_2] = "toadette_oof2.ogg"
}

--MAKING VOICE CLIPS FOR ATM. USE PLACEHOLDER VOICE CLIPS!
--[CHAR_SOUND_COUGHING1] = "peach_coughing1.ogg",
--[CHAR_SOUND_COUGHING2] = "peach_coughing2.ogg",
--[CHAR_SOUND_COUGHING3] = "peach_coughing3.ogg",
--[CHAR_SOUND_IMA_TIRED] = "peach_imatired.ogg",
--[CHAR_SOUND_ON_FIRE] = "peach_on_fire.ogg",
--[CHAR_SOUND_PANTING_COLD] = "peach_panting_cold.ogg",
--[CHAR_SOUND_SNORING1] = "peach_snoring1.ogg",
--[CHAR_SOUND_SNORING2] = "peach_snoring2.ogg",
--[CHAR_SOUND_SNORING3] = {"peach_snoring2.ogg", "peach_snoring1.ogg", "peach_snoring3.ogg"},
--[CHAR_SOUND_YAWNING] = "peach_yawning.ogg",
--[CHAR_SOUND_HELLO] = "peach_float.ogg",

local VOICETABLE_YOSHI_PLAYER = {
    [CHAR_SOUND_ATTACKED] = "yoshi_Hurt_Take_2.ogg",
    [CHAR_SOUND_DOH] = "yoshi_Hurt_Take_2.ogg",
    [CHAR_SOUND_DYING] = "yoshi_Falling_Take_1.ogg",
    [CHAR_SOUND_GROUND_POUND_WAH] = "yoshi_Wa_Take_1.ogg",
    [CHAR_SOUND_HAHA] = "yoshi_Long_Jump_Take_3.ogg",
    [CHAR_SOUND_HAHA_2] = "yoshi_Long_Jump_Take_3.ogg",
    [CHAR_SOUND_HELLO] = "yoshi_Stand_after_Triple_Jump_Take_1.ogg",
    [CHAR_SOUND_HERE_WE_GO] = "yoshi_Stand_after_Triple_Jump_Take_1.ogg",
    [CHAR_SOUND_HOOHOO] = "yoshi_DoubleJumpTake1.ogg",
    [CHAR_SOUND_IMA_TIRED] = "yoshi_Sleeping_Take_1.ogg",
    [CHAR_SOUND_LETS_A_GO] = "yoshi_Long_Jump_Take_3.ogg",
    [CHAR_SOUND_OKEY_DOKEY] = "yoshi_Stand_after_Triple_Jump_Take_1.ogg",
    [CHAR_SOUND_ON_FIRE] = "yoshi_Falling_Take_1.ogg",
    [CHAR_SOUND_PANTING] = "yoshi_Sleeping_Laying_down_Take_1.ogg",
    [CHAR_SOUND_PANTING_COLD] = "yoshi_Sleeping_Take_1.ogg",
    [CHAR_SOUND_PRESS_START_TO_PLAY] = "yoshi_Stand_after_Triple_Jump_Take_1.ogg",
    [CHAR_SOUND_PUNCH_HOO] = "yoshi_Hoo_Take_2.ogg",
    [CHAR_SOUND_PUNCH_WAH] = "yoshi_Wa_Take_1.ogg",
    [CHAR_SOUND_PUNCH_YAH] = "yoshi_DoubleJumpTake1.ogg",
    [CHAR_SOUND_SNORING1] = "yoshi_Sleeping_Take_1.ogg",
    [CHAR_SOUND_SNORING2] = "yoshi_Sleeping_Laying_down_Take_1.ogg",
    [CHAR_SOUND_SNORING3] = {"yoshi_Sleeping_Take_1.ogg", "yoshi_Sleeping_Laying_down_Take_1.ogg", "yoshi_Sleep_Talking_Take_1.ogg"},
    [CHAR_SOUND_SO_LONGA_BOWSER] = "yoshi_So_long_Bowser_Take_1.ogg",
    [CHAR_SOUND_TWIRL_BOUNCE] = "yoshi_Stand_after_Triple_Jump_Take_1.ogg",
    [CHAR_SOUND_UH] = "yoshi_Hurt_Take_2.ogg",
    [CHAR_SOUND_UH2] = "yoshi_Hoo_Take_2.ogg",
    [CHAR_SOUND_UH2_2] = "yoshi_Hurt_Take_2.ogg",
    [CHAR_SOUND_WAAAOOOW] = "yoshi_Falling_Take_2.ogg",
    [CHAR_SOUND_WAH2] = "yoshi_Wa_Take_1.ogg",
    [CHAR_SOUND_WHOA] = "yoshi_Ledge_Gra.ogg",
    [CHAR_SOUND_YAHOO] = "yoshi_Stand_after_Triple_Jump_Take_1.ogg",
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {"yoshi_Stand_after_Triple_Jump_Take_1.ogg", "yoshi_Stand_after_Triple_Jump_Take_1.ogg", "yoshi_Jump3_Take1.ogg", "yoshi_Stand_after_Triple_Jump_Take_1.ogg"},
    [CHAR_SOUND_YAH_WAH_HOO] = {"yoshi_Jump_Take1.ogg", "yoshi_Wa_Take_1.ogg", "yoshi_Ya_Take_2.ogg", "yoshi_Jump3_Take1.ogg"},
    [CHAR_SOUND_YAWNING] = "yoshi_Falling_Asleep_Take_1.ogg",
    [CHAR_SOUND_COUGHING1] = "yoshi_cough.ogg",
    [CHAR_SOUND_COUGHING2] = "yoshi_cough.ogg",
    [CHAR_SOUND_COUGHING3] = "yoshi_cough.ogg",
    [CHAR_SOUND_DROWNING] = "yoshi_underwater_suffocation.ogg",
    [CHAR_SOUND_EEUH] = "yoshi_eeuh.ogg",
    [CHAR_SOUND_HRMM] = "yoshi_hrmm.ogg",
    [CHAR_SOUND_IMA_TIRED] = "yoshi_tired.ogg",
    [CHAR_SOUND_MAMA_MIA] = "yoshi_mama_mia.ogg",
    [CHAR_SOUND_LETS_A_GO] = "yoshi_lets_a_go.ogg",
    [CHAR_SOUND_ON_FIRE] = "yoshi_on_fire.ogg",
    [CHAR_SOUND_OOOF] = "yoshi_oof.ogg",
    [CHAR_SOUND_OOOF2] = "yoshi_oof2.ogg",
    [CHAR_SOUND_PANTING] = "yoshi_pant.ogg",
    [CHAR_SOUND_PANTING_COLD] = "yoshi_pant.ogg",
    [CHAR_SOUND_SNORING1] = "yoshi_snore1.ogg",
    [CHAR_SOUND_SNORING2] = "yoshi_snore2.ogg",
    [CHAR_SOUND_SNORING3] = {"yoshi_snore1.ogg", "yoshi_snore2.ogg", "yoshi_snore3.ogg"},
    [CHAR_SOUND_YAWNING] = "yoshi_yawn.ogg",
    [CHAR_SOUND_HELLO] = "yoshi_hello.ogg"
}

local TABLE_OF_VOICES = {
    VOICETABLE_DAISY,VOICETABLE_PEACH_PLAYER,VOICETABLE_TOADETTE,VOICETABLE_YOSHI_PLAYER
}

-- Localize functions since there's WAY to many characters

local cs_char_add, cs_char_add_voice, cs_char_get_voice, cs_voice_sound, cs_voice_snore = _G.charSelect.character_add, _G.charSelect.character_add_voice, _G.charSelect.character_get_voice, _G.charSelect.voice.sound, _G.charSelect.voice.snore

if _G.charSelectExists then
    cs_char_add("Princess Daisy", {"Princess of Sarasaland","Voiced by MorphiGalaxi"}, "FluffaMario & AngelicMiracles", {r = 255, g = 97, b = 0}, E_MODEL_DAISY, CT_MARIO, TEX_DAISY_ICON)
    cs_char_add("Princess Peach", {"Princess of Mushroom Kingdom","Voiced by SuperKirbyLover"}, "FluffaMario & AngelicMiracles", {r = 239, g = 128, b = 177}, E_MODEL_PEACH_PLAYER, CT_MARIO, TEX_PEACH_PLAYER_ICON)
    cs_char_add("Toadette", {"Female Toad of Mario Kart: Double Dash!"}, "FluffaMario & AngelicMiracles", {r = 255, g = 70, b = 161}, E_MODEL_TOADETTE, CT_MARIO, TEX_TOADETTE_ICON)
    cs_char_add("Yoshi", {"Dinosuar of Mario"}, "FluffaMario & AngelicMiracles", {r = 0, g = 255, b = 0}, E_MODEL_YOSHI_PLAYER, CT_MARIO, TEX_YOSHI_PLAYER_ICON)

    -- the following must be hooked for each character added
--All Voices
    cs_char_add_voice(E_MODEL_DAISY, VOICETABLE_DAISY)
    cs_char_add_voice(E_MODEL_PEACH_PLAYER, VOICETABLE_PEACH_PLAYER)
    cs_char_add_voice(E_MODEL_TOADETTE, VOICETABLE_TOADETTE)
    cs_char_add_voice(E_MODEL_YOSHI_PLAYER, VOICETABLE_YOSHI_PLAYER)

    hook_event(HOOK_CHARACTER_SOUND, function (m, sound)
        for i = 1, #TABLE_OF_VOICES do
            if cs_char_get_voice(m) == TABLE_OF_VOICES[i] then return cs_voice_sound(m, sound) end
        end
    end)
    hook_event(HOOK_MARIO_UPDATE, function (m)
        for i = 1, #TABLE_OF_VOICES do
            if cs_char_get_voice(m) == TABLE_OF_VOICES[i] then return cs_voice_snore(m) end
        end
    end)
else
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
end