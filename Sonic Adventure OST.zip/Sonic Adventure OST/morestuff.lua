--This file fixes some of the problems with music mods, including the bug that makes bosses and other music play at the same time as the samples, 
--and it also adds some custom sfx. (by 6b)

local SAMPLE_STAR_SELECT_SIMS = audio_sample_load('StageStart.ogg')

local STREAM_STAR_SIMS = audio_stream_load('Star_Clear.ogg')
local STREAM_SLEEP_SIMS = audio_stream_load('zzz.ogg')
local STREAM_CARDCAPTOR_SAMPLE = audio_stream_load('catchyoucatchme.ogg')
local STREAM_CREDITS_SAMPLE = audio_stream_load('Ending.ogg')

	
	function musicremplace()
		if get_current_background_music() == SEQ_MENU_STAR_SELECT then
			stop_background_music(SEQ_MENU_STAR_SELECT)
			audio_sample_play(SAMPLE_STAR_SELECT_SIMS, gMarioStates[0].marioObj.header.gfx.cameraToObject, 2)
		end
	end

		--- @param m MarioState
	function on_mama_action(m)
		if m.playerIndex == 0 then 
			if m.action == ACT_STAR_DANCE_EXIT or m.action == ACT_STAR_DANCE_NO_EXIT or m.action == ACT_STAR_DANCE_WATER then
				audio_stream_play(STREAM_STAR_SIMS, false, 1)
				audio_stream_set_looping(STREAM_STAR_SIMS, false)
				end
			end
		end

		hook_event(HOOK_ON_SET_MARIO_ACTION, on_mama_action)

			--- @param m MarioState
		function on_sleep_action(m)
			if m.playerIndex == 0 then 
				if m.action == ACT_SLEEPING then
					audio_stream_play(STREAM_SLEEP_SIMS, false, 1)
					audio_stream_set_looping(STREAM_SLEEP_SIMS, false)
				else
					audio_stream_stop(STREAM_SLEEP_SIMS)
				end
			end
		end
	
			hook_event(HOOK_ON_SET_MARIO_ACTION, on_sleep_action)

					--- @param m MarioState
	function on_intro_action(m)
		if m.playerIndex == 0 then 
			if m.action == ACT_INTRO_CUTSCENE then
				audio_stream_play(STREAM_CARDCAPTOR_SAMPLE, false, 1)
				audio_stream_set_looping(STREAM_CARDCAPTOR_SAMPLE, false)
				end
			end
		end

		hook_event(HOOK_ON_SET_MARIO_ACTION, on_intro_action)

							--- @param m MarioState
	function on_credits_action(m)
		if m.playerIndex == 0 then 
			if m.action == ACT_END_PEACH_CUTSCENE or m.action == ACT_CREDITS_CUTSCENE or m.action == ACT_END_WAVING_CUTSCENE then
				audio_stream_play(STREAM_CREDITS_SAMPLE, false, 1)
				audio_stream_set_looping(STREAM_CREDITS_SAMPLE, false)
			else
				audio_stream_stop(STREAM_CREDITS_SAMPLE)
				end
			end
		end

		hook_event(HOOK_ON_SET_MARIO_ACTION, on_credits_action)

hook_event(HOOK_UPDATE, musicremplace)
