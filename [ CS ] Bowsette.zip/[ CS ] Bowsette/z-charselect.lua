if not _G.charSelectExists then return end

local E_MODEL_BOWSETTE_PLAYER = smlua_model_util_get_id('bowsette_player_geo')


local CAPTABLE_KOOP = {
    normal = smlua_model_util_get_id('koop_cap_geo'),
    wing = smlua_model_util_get_id('koop_wing_cap_geo'),
    metal = smlua_model_util_get_id('koop_metal_cap_geo'),
    metalWing = smlua_model_util_get_id('koop_metal_wing_cap_geo'),
}

---- BOWSETTE MOVESET:

if _G.bowsMoveset then
    -- Retrieves the custom shell model for this character. Check template_shell.blend for how to set up a shell model properly.
    local E_MODEL_BOWSETTE_SHELL = smlua_model_util_get_id('bowsette_shell_geo')


    -- This is a bitfield of flags that decide which parts of the Bowser Moveset this character will have.
    -- Insert each flag you want to be set, separated by '|' symbols.
    local BOWS_FLAGS_JR =
        _G.bowsMoveset.FLAG_CAN_USE_FIREBALL | _G.bowsMoveset.FLAG_CAN_USE_SHELL | _G.bowsMoveset.FLAG_NO_CAPLESS |
        _G.bowsMoveset.FLAG_STYLE_ANIMS

    -- Flag Options: (sorry the ids are so long pshgkjdf)

    -- _G.bowsMoveset.FLAG_CAN_USE_SHELL
    --- Allows the character to use the shell slide ability.

    -- _G.bowsMoveset.FLAG_CAN_USE_FIREBALL
    --- Allows the character to use the fire breath ability.

    -- _G.bowsMoveset.FLAG_STYLE_ANIMS
    --- Enables Bowser-unique animations for the character.

    -- _G.bowsMoveset.FLAG_SIZE_ANIMS
    --- Adjusts the character's pose in certain animations to suit bowser's large size. (i.e. ledge grab)

    -- _G.bowsMoveset.FLAG_LARGE_HITBOX
    --- Gives the character a larger hitbox size. (37 -> 85 units radius)
    --- This does not affect the hitbox size for level collision, only collisions with objects.

    -- _G.bowsMoveset.FLAG_NO_CAPLESS
    --- The character does not visually lose their 'cap'. Will also use their 'capless' head state in some animations.
    --- Used by Bowser to allow his jaw to open when breathing fire, etc.

    -- _G.bowsMoveset.FLAG_HEAVY_STEPS
    --- Enables heavier landing sound effects for the character.

    -- _G.bowsMoveset.FLAG_ATTACKS
    --- Enables the alternate sliding punch.

    -- _G.bowsMoveset.FLAG_ALL
    --- Shorthand to set all flags.


    -- This function sets up your custom shell model. Feel free to remove this if you aren't using a shell model.
    -- parameters: [your character model], [your shell model], [custom shell sound]
    _G.bowsMoveset.character_add_shell_model(E_MODEL_JR, E_MODEL_JR_SHELL, 'shell_jr.ogg')
    -- This function sets up the flags for your character.
    -- parameters: [your character model], [your flag bitfield]
    _G.bowsMoveset.character_set_bows_flags(E_MODEL_JR, BOWS_FLAGS_JR)

    -- repeated for bowser
    _G.bowsMoveset.character_add_shell_model(E_MODEL_BOWSETTE_PLAYER, E_MODEL_BOWSETTE_SHELL)
    _G.bowsMoveset.character_set_bows_flags(E_MODEL_BOWSETTE_PLAYER, bowsMoveset.FLAG_ALL)
end
----

_G.charSelect.character_add_palette_preset(E_MODEL_BOWSETTE_PLAYER, PALETTE_BOWSETTE)


_G.charSelect.character_add_caps(E_MODEL_BOWSETTE_PLAYER, CAPTABLE_KOOP)

_G.charSelect.character_add_voice(E_MODEL_BOWSETTE_PLAYER, VOICETABLE_BOWSETTE)

hook_event(HOOK_CHARACTER_SOUND, function(m, sound)
    local voice = _G.charSelect.character_get_voice(m)
    if voice == VOICETABLE_BOWSETTE
        or voice == VOICETABLE_JR
    then
        return _G.charSelect.voice.sound(m, sound)
    end
end)
hook_event(HOOK_MARIO_UPDATE, function(m)
    if m.action ~= ACT_SLEEPING then return end

    local voice = _G.charSelect.character_get_voice(m)
    if voice == VOICETABLE_BOWSETTE
        or voice == VOICETABLE_JR
    then
        return _G.charSelect.voice.snore(m)
    end
end)
