if not _G.charSelectExists then return end

local E_BOWSETTE_PLAYER_MODEL = smlua_model_util_get_id("bowsette_player_geo")

local TEX_BOWSETTE = get_texture_info("bowsette_icon")

local CAPTABLE_KOOP = {
    normal = smlua_model_util_get_id("koop_cap_geo"),
    wing = smlua_model_util_get_id("koop_wing_cap_geo"),
    metal = smlua_model_util_get_id("koop_metal_cap_geo"),
    metalWing = smlua_model_util_get_id("koop_metal_wing_cap_geo"),
}

local VOICETABLE_BOWSETTE = {
    [CHAR_SOUND_ATTACKED] = 'bw_ouch.ogg',
    [CHAR_SOUND_DOH] = 'bw_bonk2.ogg',
    [CHAR_SOUND_DROWNING] = 'bw_dying.ogg',
    [CHAR_SOUND_DYING] = 'bw_dying.ogg',
    [CHAR_SOUND_EEUH] = 'bw_jump0.ogg',
    [CHAR_SOUND_GROUND_POUND_WAH] = 'bw_bonk0.ogg',
    [CHAR_SOUND_HAHA] = 'bw_haha.ogg',
    [CHAR_SOUND_HAHA_2] = 'bw_haha.ogg',
    [CHAR_SOUND_HERE_WE_GO] = 'bw_herewego.ogg',
    [CHAR_SOUND_HOOHOO] = 'bw_doublejump.ogg',
    [CHAR_SOUND_HRMM] = 'bw_bonk2.ogg',
    [CHAR_SOUND_MAMA_MIA] = 'bw_mamamia.ogg',
    [CHAR_SOUND_LETS_A_GO] = 'bw_letsgo.ogg',
    [CHAR_SOUND_ON_FIRE] = 'bw_hothot.ogg',
    [CHAR_SOUND_OOOF] = 'bw_bonk0.ogg',
    [CHAR_SOUND_OOOF2] = 'bw_bonk0.ogg',
    [CHAR_SOUND_PUNCH_HOO] = 'bw_attack2.ogg',
    [CHAR_SOUND_PUNCH_WAH] = 'bw_jump1.ogg',
    [CHAR_SOUND_PUNCH_YAH] = 'bw_attack1.ogg',
    [CHAR_SOUND_SO_LONGA_BOWSER] = 'bw_haha.ogg',
    [CHAR_SOUND_TWIRL_BOUNCE] = 'bw_wahoo1.ogg',
    [CHAR_SOUND_UH2] = 'bw_bonk1.ogg',
    [CHAR_SOUND_WAAAOOOW] = 'bw_falling.ogg',
    [CHAR_SOUND_WAH2] = 'bw_attack2.ogg',
    [CHAR_SOUND_WHOA] = 'bw_bonk2.ogg',
    [CHAR_SOUND_YAHOO] = 'bw_wahoo1.ogg',
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = { 'bw_wahoo0.ogg', 'bw_wahoo1.ogg' },
    [CHAR_SOUND_YAH_WAH_HOO] = { 'bw_jump0.ogg', 'bw_jump1.ogg' },
}


-- Localize functions since there's WAY to many characters

local PALETTE_BOWSETTE = {
    [SHIRT] = "ffffff",
    [SHOES] = "40343E",
    [HAIR] = "E85E44",
    [CAP] = "AB97A2",
    [PANTS] = "428119",
    [GLOVES] = "ffffff",
    [SKIN] = "BD7739",
}

CT_CHAR = _G.charSelect.character_add("Bowsette", {"Evil Queen of the Koopas! Strong!","Pretty! Irreristible to women!"}, "Melzinoff & Gauntlet Queen", {r = 239, g = 128, b = 177}, E_BOWSETTE_PLAYER_MODEL, CT_MARIO, TEX_BOWSETTE)
_G.charSelect.character_add_caps(E_BOWSETTE_PLAYER_MODEL, CAPTABLE_KOOP)
_G.charSelect.character_add_voice(E_BOWSETTE_PLAYER_MODEL, VOICETABLE_BOWSETTE)

hook_event(HOOK_CHARACTER_SOUND, function (m, sound)
    if _G.charSelect.character_get_voice(m) == VOICETABLE_BOWSETTE then return
_G.charSelect.voice.sound(m, sound) end
end)

hook_event(HOOK_MARIO_UPDATE, function (m)
    if _G.charSelect.character_get_voice(m) == VOICETABLE_BOWSETTE then return _G.charSelect.voice.snore(m) end
end)