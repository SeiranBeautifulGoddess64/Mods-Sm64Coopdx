-- name:\\#F78AF5\\!B3\\#F94A36\\3\\#4C5BFF\\13\\#EDD83D\\Sound\\#16C31C\\track!\\
-- description: Music from \\FFFFFF\\Beta 3313 of \\0CFF00\\Super \\808B96\\Mario \\FFFFFF\\64.
local bgms = {
	--This is where streamed audios are defined. 
	--You can find the Level ID by turning on pauseMenuShowLevelID and going to the area, then pausing.
	--'Level ID' -2 is uniquely used for the cap music in this mod as well. So assign audio to -2 to change the cap music.
	--The audio file is expected to be under %ThisModFolder%/sound/
	--This might sound weird, but SM64ex-coop has a weird issue with filenames that are too similar. So try making the audio files very differently named from eachother.
	[-2] =         {audio='CapPowerUp.ogg', loopEnd = 441144, loopStart = 0.5, volume = 1.25, name="Prototype"},
	[9] =         {audio='StageBombs.ogg',      loopEnd = 3175889, loopStart = 0.5, volume = 1, name="Strangetown"},
	[6] =         {audio='CastlePeach.ogg', loopEnd = 5096766, loopStart = 0.5, volume = 1.25, name="stange_day"},
	[24] =         {audio='StageTower.ogg',      loopEnd = 3175430, loopStart = 0.5, volume = 1, name="Strangetown Prototype"},
	[27] =         {audio='BonusStage.ogg', loopEnd = 1638991, loopStart = 0.5, volume = 1.1, name="Chug-Chug Cola"},
	[18] =         {audio='BonusStage.ogg', loopEnd = 4403606, loopStart = 0.5, volume = 1.25, name="Create Sim"},
	[29] =         {audio='StageSky.ogg', loopEnd = 3175430, loopStart = 0.5, volume = 1, name="Strangetown Prototype (wing cap)"},
	[12] =         {audio='StageWater.ogg', loopEnd = 3387542, loopStart = 0.5, volume = 1.2, name="Walk the plank"},
	[23] =         {audio='StageWater.ogg', loopEnd = 3175889, loopStart = 0.5, volume = 1.45, name="bloom (swim)"},
	[20] =         {audio='StageWater.ogg', loopEnd = 5087486, loopStart = 0.5, volume = 1.45, name="investigate (swim)"},
	[17] =         {audio='FinalBoss.ogg', loopEnd = 3763353, loopStart = 0.5, volume = 1.1, name="Ratticator (bowser 1)"},
	[5] =         {audio='IceStage.ogg', loopEnd = 3024246, loopStart = 0.5, volume = 1, name="Friendship"},
	[4] =         {audio='StageHouseGhost.ogg', loopEnd = 1913647, loopStart = 0.5, volume = 1.15, name="Alien Invasion!"},
	[19] =        {audio='FinalBoss.ogg', loopEnd = 5096766, loopStart = 0.5, volume = 1.15, name="Heavy Metal (bowser2)"},
	[22] =        {audio='StageFire.ogg', loopEnd = 4182354, loopStart = 0.5, volume = 1.45, name="investigate (hot)"},
	[8] =         {audio='StageDessert.ogg', loopEnd = 5087486, loopStart = 0.5, volume = 1.45, name="investigate (dessert)"},
	[7] =         {audio='StageHaze.ogg', loopEnd = 3256880, loopStart = 0.5, volume = 1.25, name="strange_night"},
	[28] =         {audio='StageHaze.ogg', loopEnd = 3256880, loopStart = 0.5, volume = 1.25, name="strange_night"},
	[36] =         {audio='StageMushroom.ogg',      loopEnd = 3175430, loopStart = 0.5, volume = 1.15, name="Moogoo Monkey"},
	[13] =         {audio='Stage-Big-Mini.ogg', loopEnd = 1355414, loopStart = 0.5, volume = 1.2, name="The Sims 2 NDS - Title Screen (tiny-big)"},
	[11] =         {audio='Stage-Water-Up-Down.ogg', loopEnd = 4705021, loopStart = 0.5, volume = 1.25, name="Edge of Town"},
	[10] =         {audio='IceStage.ogg', loopEnd = 1355414, loopStart = 0.5, volume = 1.2, name="The Sims 2 NDS - Title Screen (snow)"},
	[31] =         {audio='StageSky.ogg',      loopEnd = 3175430, loopStart = 0.5, volume = 1, name="Strangetown Prototype (cloud)"},
	[14] =         {audio='StageClock.ogg', loopEnd = 2945832, loopStart = 0.5, volume = 1.2, name="bigfoot"},
	[15] =         {audio='StageSky.ogg', loopEnd = 4403606, loopStart = 0.5, volume = 1.25, name="Create Sim (level-sky)"},
	[21] =         {audio='FinalBoss.ogg', loopEnd = 3848866, loopStart = 0.5, volume = 1.15, name="Speed Metal (bowser3)"},
}

--Feel free to turn this off if (you don't want to show the music name in the pause menu
local pauseMenuShouldShowMusic = true
local pauseMenuMusicRGBA = {200,200,200,255}

--Don't know what course ID to put for a map? No worries. Just turn this to true, and the pause menu will show the course number in the corner.
--This requires pauseMenuShouldShowMusic to be true to show up.
local pauseMenuShowLevelID = true

--Below here is just a bunch of internal stuff.
--Feel free to copy/paste/alter it as you like in your own works. I'd like to ask for credit in the form of a lua comment, but I'm not a stickler about it.
--Apologies if any of the code is ugly. I have little lua experience compared to some other languages.
local curMap = -1
local audioMainPaused = false
CreditsVolume = 1
local audioMain = nil --Used for the main audio
local audioSpecial = nil --Used for things like cap music
local audioCurSeq = nil
function handleMusic()
	------------------------------------------------------
    --          Handle stopping/starting of music       --
	------------------------------------------------------
	--Handle main course music
    if (curMap ~= gNetworkPlayers[0].currLevelNum and gMarioStates[0].area.macroObjects ~= nil) then
        curMap = gNetworkPlayers[0].currLevelNum
		audioCurSeq = get_current_background_music()
        if (audioMain ~= nil) then
            audio_stream_stop(audioMain)
            audio_stream_destroy(audioMain)
            audioMain = nil
        end
        if (bgms[curMap] ~= nil and bgms[curMap].audio ~= nil) then 
            set_background_music(0,0,0)
            audioMain = audio_stream_load(bgms[curMap].audio)
            if (audioMain ~= nil) then
                audio_stream_set_looping(audioMain, true)
                audio_stream_play(audioMain, true, bgms[curMap].volume * CreditsVolume);
                print("Playing new audio " .. bgms[curMap].name)
            else
                djui_popup_create('Missing audio!: ' .. bgms[curMap].audio, 10)
                print("Attempted to load filed audio file, but couldn't find it on the system: " .. bgms[curMap].audio)
            end
        else
            print("No audio for this map, so not stopping default: " .. curMap)
        end
    end

	--Handle cap music
	if (gMarioStates[0].capTimer > 0 and bgms[-2] ~= nil)then
		--Handle pausing main streamed music, if applicable.
		if (audioMain ~= nil and audioMainPaused == false) then
			audioMainPaused = true
			audio_stream_pause(audioMain)
		end
		--Start up cap music if it's defined.
		if (audioSpecial == nil) then
            set_background_music(0,0,0)
			stop_cap_music()
			audioSpecial = audio_stream_load(bgms[-2].audio)
			if (audioSpecial ~= nil) then
				audio_stream_set_looping(audioSpecial, true)
				audio_stream_play(audioSpecial, true, bgms[-2].volume * CreditsVolume)
				print("Playing cap audio " .. bgms[-2].name)
			else
				djui_popup_create('Missing audio!: ' .. bgms[-2].audio, 3)
                print("Attempted to load filed audio file, but couldn't find it on the system: " .. bgms[-2].audio)
			end
		end	
	else
		if (audioSpecial ~= nil) then
			audio_stream_stop(audioSpecial)
			audio_stream_destroy(audioSpecial)
			audioSpecial = nil
			if (audioMain ~= nil and audioMainPaused == true) then
				audioMainPaused = false
				audio_stream_play(audioMain, false, bgms[curMap].volume * CreditsVolume)
			else
				set_background_music(0, audioCurSeq, 10) 
			
			end
		end
	end

	------------------------------------------------------
    --                Handle music looping              --
	------------------------------------------------------
    if (audioMain ~= nil) then 
		local curPosition = audio_stream_get_position(audioMain)
		if (curPosition >= bgms[curMap].loopEnd ) then
			local minus = bgms[curMap].loopStart - bgms[curMap].loopEnd
			audio_stream_set_position(audioMain, curPosition - math.abs(minus))
		end
    end
	if (audioSpecial ~= nil) then
		local curPosition = audio_stream_get_position(audioSpecial)
		if (curPosition >= bgms[-2].loopEnd) then
			local minus = bgms[-2].loopStart - bgms[-2].loopEnd
			audio_stream_set_position(audioSpecial, curPosition - math.abs(minus))
		end
	end
end

	--- @param m MarioState
function on_sit_action(m)
	if m.playerIndex == 0 then 
		if (m.action == ACT_DISAPPEARED or m.action == ACT_STAR_DANCE_EXIT or m.action == ACT_STAR_DANCE_NO_EXIT or m.action == ACT_STAR_DANCE_WATER or m.action == ACT_SLEEPING or m.action == ACT_BBH_ENTER_SPIN) and (audioMain ~= nil and audioMainPaused == false) then
				audioMainPaused = true
				audio_stream_pause(audioMain)
		else
			if (audioMain ~= nil and audioMainPaused == true) then
				audioMainPaused = false
				audio_stream_play(audioMain, false, bgms[curMap].volume * CreditsVolume)
			end
		end
	end
end

hook_event(HOOK_ON_SET_MARIO_ACTION, on_sit_action)

	--- @param m MarioState
	function on_credits_action(m)
		if m.playerIndex == 0 then 
			if (m.action == ACT_CREDITS_CUTSCENE or m.action == ACT_END_PEACH_CUTSCENE)then
					CreditsVolume = 0
			else
					CreditsVolume = 1
				end
			end
		end
	
	hook_event(HOOK_ON_SET_MARIO_ACTION, on_credits_action)

function hud_render()
    if (pauseMenuShouldShowMusic == true and is_game_paused()) then
        djui_hud_set_resolution(RESOLUTION_DJUI);
        djui_hud_set_font(FONT_NORMAL);
        local screenWidth = djui_hud_get_screen_width()
		local screenHeight = djui_hud_get_screen_height()
        local height = 64
        local y = screenHeight - height
        djui_hud_set_color(pauseMenuMusicRGBA[1], pauseMenuMusicRGBA[2], pauseMenuMusicRGBA[3], pauseMenuMusicRGBA[4]);		
		local text = "";
		if (pauseMenuShowLevelID == true) then
			text = "Level ID: " .. gNetworkPlayers[0].currLevelNum
		elseif (audioSpecial ~= nil) then
			text = "Music: " .. bgms[-2].name
		elseif (audioMain ~= nil) then
			text = "Music: " .. bgms[curMap].name
		end
		djui_hud_print_text(text, 5, y, 1);
    end
end
hook_event(HOOK_ON_HUD_RENDER, hud_render)
smlua_audio_utils_replace_sequence(SEQ_EVENT_CUTSCENE_COLLECT_STAR, 34, 0, "silent_star")
smlua_audio_utils_replace_sequence(SEQ_EVENT_CUTSCENE_COLLECT_KEY, 34, 0, "silent_star")
hook_event(HOOK_UPDATE, handleMusic)
-----------------------------------------------------------------------------
--                           Music Mod End                                 --
-----------------------------------------------------------------------------