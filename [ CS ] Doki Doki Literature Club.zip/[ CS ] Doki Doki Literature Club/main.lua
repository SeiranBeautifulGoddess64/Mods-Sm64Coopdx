-- name: [CS] \\#c84cbc\\Doki Doki Model Pack!
-- description: Adds characters from Doki Doki\nLiterature Club to your character \nselect roster!\n(currently just Monika and Sayori)\n\n\\#ffffdc\\Requires Character Select!

local TEXT_MOD_NAME = "DDLC Model Pack"
local TEXT_MOD_VERSION = "Version 1"
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end




local E_SAYORI_MODEL = smlua_model_util_get_id("Sayori_geo")
local TEX_SAYORI_ICON = get_texture_info("sayori-icon")
local CAPTABLE_SAYORI = {
    normal = smlua_model_util_get_id("Sayori_Bow_geo"),
    wing = smlua_model_util_get_id("Sayori_Bow_geo"),
    metal = smlua_model_util_get_id("Sayori_Bow_geo"),
    metalWing = smlua_model_util_get_id("Sayori_Bow_geo"),
}

local VOICETABLE_SAYORI = {
    [CHAR_SOUND_ATTACKED] = {'say-hyn.ogg', 'say-wah.ogg', 'say-ouch.ogg', 'say-ouchie.ogg', 'say-kyaah.ogg', 'say-please-stop.ogg'},
    [CHAR_SOUND_DOH] = {'say-ouch.ogg', 'say-ouchie.ogg', 'say-ow-that-hurt.ogg'},
    [CHAR_SOUND_DYING] = {'say-ahh.ogg', 'say-im-no-good.ogg'},
    [CHAR_SOUND_GROUND_POUND_WAH] = {'say-hyah-2.ogg'},
    [CHAR_SOUND_HAHA] = 'say-did-it.ogg',
    [CHAR_SOUND_HAHA_2] = 'say-did-it.ogg',
    [CHAR_SOUND_HERE_WE_GO] = {'say-like-this.ogg', 'say-lets-go.ogg', 'say-did-it.ogg', 'say-here-i-come.ogg'},
    [CHAR_SOUND_HOOHOO] = {'say-ek.ogg', 'say-tok.ogg'},
    [CHAR_SOUND_MAMA_MIA] = {'say-sorry.ogg', 'say-yikes.ogg', 'say-whew.ogg', 'say-im-fine.ogg', 'say-all-hurt.ogg'},
    [CHAR_SOUND_OKEY_DOKEY] = {'say-ok.ogg', 'say-ok-2.ogg', 'say-lets-go.ogg', 'say-my-best.ogg', 'say-no-problem.ogg'},
    [CHAR_SOUND_ON_FIRE] = {'say-eahhah.ogg', 'say-kyaah.ogg'},
    [CHAR_SOUND_OOOF] = {'say-hyn.ogg', 'say-wahah.ogg', 'say-wah.ogg', 'say-ouch.ogg', 'say-ouchie.ogg'},
    [CHAR_SOUND_OOOF2] = {'say-hyn.ogg', 'say-wahah.ogg', 'say-wah.ogg', 'say-ouch.ogg', 'say-ouchie.ogg'},
    [CHAR_SOUND_PUNCH_HOO] = {'say-yes.ogg', 'say-yes.ogg', 'say-hyah-2.ogg', 'say-hyah-2.ogg', 'say-this.ogg', 'say-this-2.ogg'},
    [CHAR_SOUND_PUNCH_WAH] = {'say-yes.ogg', 'say-yes.ogg', 'say-hyah-2.ogg', 'say-hyah-2.ogg', 'say-this.ogg', 'say-this-2.ogg'},
    [CHAR_SOUND_PUNCH_YAH] = {'say-yes.ogg', 'say-yes.ogg', 'say-hyah-2.ogg', 'say-hyah-2.ogg', 'say-this.ogg', 'say-this-2.ogg'},
    [CHAR_SOUND_SO_LONGA_BOWSER] = {'say-take-this.ogg', 'say-take-this.ogg', 'say-take-this-2.ogg', 'say-take-this-2.ogg', 'say-the-finisher.ogg'},
    [CHAR_SOUND_TWIRL_BOUNCE] = {'say-yes.ogg'},
    [CHAR_SOUND_WAAAOOOW] = {'say-eahhah.ogg', 'say-oh-no.ogg'},
    [CHAR_SOUND_WAH2] = {'say-hmm.ogg', 'say-whew.ogg', 'say-um.ogg', 'say-um-2.ogg', 'say-wah.ogg', 'say-ehh.ogg'},
    [CHAR_SOUND_WHOA] = {'say-hmm.ogg', 'say-whew.ogg', 'say-um.ogg', 'say-um-2.ogg', 'say-wah.ogg', 'say-ehh.ogg'},
    [CHAR_SOUND_YAHOO] = {'say-yay.ogg', 'say-yay-3.ogg', 'say-yay-2.ogg', 'say-hahh.ogg', 'say-gooo.ogg'},
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'say-yay.ogg', 'say-yay-3.ogg', 'say-yay-2.ogg', 'say-hahh.ogg', 'say-gooo.ogg'},
    [CHAR_SOUND_YAH_WAH_HOO] = {'say-ek.ogg', 'say-tok.ogg'},
    [CHAR_SOUND_YAWNING] = {'say-whew.ogg', 'say-whew.ogg', 'say-whew.ogg', 'say-short-rest.ogg'},
}



local E_MONIKA_MODEL = smlua_model_util_get_id("Monika_geo")
local TEX_MONIKA_ICON = get_texture_info("monika-icon")
local CAPTABLE_MONIKA = {
    normal = smlua_model_util_get_id("Monika_Bow_geo"),
    wing = smlua_model_util_get_id("Monika_Bow_geo"),
    metal = smlua_model_util_get_id("Monika_Bow_geo"),
    metalWing = smlua_model_util_get_id("Monika_Bow_geo"),
}

local VOICETABLE_MONIKA = {
    [CHAR_SOUND_ATTACKED] = {'mon-gasp.ogg', 'mon-ow.ogg', 'mon-scream-2.ogg', 'mon-ugh.ogg'},
    [CHAR_SOUND_DOH] = {'mon-grunt.ogg', 'mon-no.ogg', 'mon-oh.ogg', 'mon-shoot.ogg'}, 
    [CHAR_SOUND_DYING] = {'mon-it-cant-be.ogg', 'mon-im-sorry.ogg'},
    [CHAR_SOUND_GROUND_POUND_WAH] = 'mon-thats-right-2.ogg',
    [CHAR_SOUND_HAHA] = {'mon-giggle.ogg', 'mon-laugh.ogg'},
    [CHAR_SOUND_HAHA_2] = {'mon-giggle.ogg', 'mon-laugh.ogg'},
    [CHAR_SOUND_HERE_WE_GO] = {'mon-giggle.ogg', 'mon-laugh.ogg', 'mon-got-it.ogg'},
    [CHAR_SOUND_MAMA_MIA] = {'mon-aw-jeez.ogg', 'mon-cant-be-happening.ogg', 'mon-im-fine.ogg', 'mon-uhh-oh.ogg'},
    [CHAR_SOUND_OKEY_DOKEY] = {'mon-alright.ogg', 'mon-ill-do-it.ogg'},
    [CHAR_SOUND_ON_FIRE] = {'mon-ah-2.ogg', 'mon-scream-2.ogg', 'mon-scream-4.ogg'},
    [CHAR_SOUND_OOOF] = {'mon-ow.ogg', 'mon-gasp.ogg', 'mon-ugn.ogg'},
    [CHAR_SOUND_OOOF2] = {'mon-ow.ogg', 'mon-gasp.ogg', 'mon-ugn.ogg'},
    [CHAR_SOUND_PUNCH_YAH] = {'mon-ite.ogg', 'mon-hup-2.ogg'},
    [CHAR_SOUND_PUNCH_WAH] = {'mon-ite.ogg', 'mon-hup-2.ogg'},
    [CHAR_SOUND_PUNCH_HOO] = 'mon-yeah.ogg',
    [CHAR_SOUND_SO_LONGA_BOWSER] = {'mon-thats-right-2.ogg', 'mon-this-is-it.ogg'},
    [CHAR_SOUND_TWIRL_BOUNCE] = {'mon-giggle.ogg', 'mon-laugh.ogg'},
    [CHAR_SOUND_WAAAOOOW] = {'mon-huh-8.ogg', 'mon-scream.ogg', 'mon-scream-4.ogg'},
    [CHAR_SOUND_WAH2] = {'mon-whew.ogg', 'mon-huh-2.ogg'},
    [CHAR_SOUND_WHOA] = {'mon-whew.ogg', 'mon-huh-2.ogg'},
    [CHAR_SOUND_YAH_WAH_HOO] = {'mon-huh-7.ogg', 'mon-hup.ogg', 'mon-un.ogg'},
    [CHAR_SOUND_HOOHOO] = {'mon-huh-7.ogg', 'mon-hup.ogg', 'mon-un.ogg'},
    [CHAR_SOUND_YAHOO] = {'mon-woah.ogg', 'mon-woah-2.ogg', 'mon-thats-right.ogg'},
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'mon-huh-7.ogg', 'mon-hup.ogg'},
    [CHAR_SOUND_YAWNING] = {'mon-aw-2.ogg', 'mon-hmm.ogg', 'mon-hmm-2.ogg'},
}

-- Localize functions since there's WAY to many characters

CT_CHAR = _G.charSelect.character_add("Monika", {"Voice is Kaede Akamatsu from","Danganronpa V3"}, "GalacticalXenon", {r = 158, g = 93, b = 69}, E_MONIKA_MODEL, CT_MARIO, TEX_MONIKA_ICON)
_G.charSelect.character_add_caps(E_MONIKA_MODEL, CAPTABLE_MONIKA)
_G.charSelect.character_add_voice(E_MONIKA_MODEL, VOICETABLE_MONIKA)

CT_CHAR = _G.charSelect.character_add("Sayori", {"Voice is Nepgear from","Hyperdimension Neptunia"}, "GalacticalXenon", {r = 240, g = 160, b = 138}, E_SAYORI_MODEL, CT_MARIO, TEX_SAYORI_ICON)
_G.charSelect.character_add_caps(E_SAYORI_MODEL, CAPTABLE_SAYORI)
_G.charSelect.character_add_voice(E_SAYORI_MODEL, VOICETABLE_SAYORI)


hook_event(HOOK_CHARACTER_SOUND, function (m, sound)
    if _G.charSelect.character_get_voice(m) == VOICETABLE_SAYORI or _G.charSelect.character_get_voice(m) == VOICETABLE_MONIKA then return _G.charSelect.voice.sound(m, sound) end
end)
hook_event(HOOK_MARIO_UPDATE, function (m)
    if _G.charSelect.character_get_voice(m) == VOICETABLE_SAYORI or _G.charSelect.character_get_voice(m) == VOICETABLE_MONIKA then return _G.charSelect.voice.snore(m) end
end)