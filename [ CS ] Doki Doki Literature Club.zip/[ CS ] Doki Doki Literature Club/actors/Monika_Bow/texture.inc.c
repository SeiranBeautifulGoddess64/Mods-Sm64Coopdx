Gfx Monika_Bow_Metal_Shade_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_Bow_Metal_Shade_rgba16_rgba16[] = {
	#include "Monika/Metal_Shade.rgba16.inc.c"
};

Gfx Monika_Bow_Metal_Light_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_Bow_Metal_Light_rgba16_rgba16[] = {
	#include "Monika/Metal_Light.rgba16.inc.c"
};

