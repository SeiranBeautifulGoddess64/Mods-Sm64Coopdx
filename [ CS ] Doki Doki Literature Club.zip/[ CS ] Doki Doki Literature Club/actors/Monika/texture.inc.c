Gfx Monika_Button_ci4_aligner[] = {gsSPEndDisplayList()};
u8 Monika_Button_ci4[] = {
	#include "Monika/Button.ci4.inc.c"
};

Gfx Monika_Button_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_Button_pal_rgba16[] = {
	#include "Monika/Button.rgba16.pal"
};

Gfx Monika_shirt_ci4_aligner[] = {gsSPEndDisplayList()};
u8 Monika_shirt_ci4[] = {
	#include "Monika/shirt.ci4.inc.c"
};

Gfx Monika_shirt_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_shirt_pal_rgba16[] = {
	#include "Monika/shirt.rgba16.pal"
};

Gfx Monika_ribbon_ci4_aligner[] = {gsSPEndDisplayList()};
u8 Monika_ribbon_ci4[] = {
	#include "Monika/ribbon.ci4.inc.c"
};

Gfx Monika_ribbon_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_ribbon_pal_rgba16[] = {
	#include "Monika/ribbon.rgba16.pal"
};

Gfx Monika_monFace_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_monFace_rgba16[] = {
	#include "Monika/monFace.rgba16.inc.c"
};

Gfx Monika_monFaceHalfEyes_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_monFaceHalfEyes_rgba16[] = {
	#include "Monika/monFaceHalfEyes.rgba16.inc.c"
};

Gfx Monika_monFaceClosedEyes_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_monFaceClosedEyes_rgba16[] = {
	#include "Monika/monFaceClosedEyes.rgba16.inc.c"
};

Gfx Monika_monFaceDie_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_monFaceDie_rgba16[] = {
	#include "Monika/monFaceDie.rgba16.inc.c"
};

Gfx Monika_wing_2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_wing_2_rgba16[] = {
	#include "Monika/wing_2.rgba16.inc.c"
};

Gfx Monika_wing1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_wing1_rgba16[] = {
	#include "Monika/wing1.rgba16.inc.c"
};

Gfx Monika_Metal_Shade_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_Metal_Shade_rgba16_rgba16[] = {
	#include "Monika/Metal_Shade.rgba16.inc.c"
};

Gfx Monika_Metal_Light_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_Metal_Light_rgba16_rgba16[] = {
	#include "Monika/Metal_Light.rgba16.inc.c"
};

Gfx Monika_custom_mario_metal_wing_tip_shade_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_custom_mario_metal_wing_tip_shade_rgba16[] = {
	#include "Monika/custom_mario_metal_wing_tip_shade.rgba16.inc.c"
};

Gfx Monika_custom_mario_metal_wing_tip_light_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_custom_mario_metal_wing_tip_light_rgba16[] = {
	#include "Monika/custom_mario_metal_wing_tip_light.rgba16.inc.c"
};

Gfx Monika_custom_mario_metal_wing_shade_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_custom_mario_metal_wing_shade_rgba16[] = {
	#include "Monika/custom_mario_metal_wing_shade.rgba16.inc.c"
};

Gfx Monika_custom_mario_metal_wing_light_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Monika_custom_mario_metal_wing_light_rgba16[] = {
	#include "Monika/custom_mario_metal_wing_light.rgba16.inc.c"
};

