Gfx Yuri_Button_ci4_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_Button_ci4[] = {
	#include "Yuri/Button.ci4.inc.c"
};

Gfx Yuri_Button_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_Button_pal_rgba16[] = {
	#include "Yuri/Button.rgba16.pal"
};

Gfx Yuri_shirt_ci4_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_shirt_ci4[] = {
	#include "Yuri/shirt.ci4.inc.c"
};

Gfx Yuri_shirt_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_shirt_pal_rgba16[] = {
	#include "Yuri/shirt.rgba16.pal"
};

Gfx Yuri_ribbon_ci4_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_ribbon_ci4[] = {
	#include "Yuri/ribbon.ci4.inc.c"
};

Gfx Yuri_ribbon_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_ribbon_pal_rgba16[] = {
	#include "Yuri/ribbon.rgba16.pal"
};

Gfx Yuri_yuriFace_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_yuriFace_rgba16[] = {
	#include "Yuri/yuriFace.rgba16.inc.c"
};

Gfx Yuri_yuriFaceHalfEyes_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_yuriFaceHalfEyes_rgba16[] = {
	#include "Yuri/yuriFaceHalfEyes.rgba16.inc.c"
};

Gfx Yuri_yuriFaceClosedEyes_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_yuriFaceClosedEyes_rgba16[] = {
	#include "Yuri/yuriFaceClosedEyes.rgba16.inc.c"
};

Gfx Yuri_YuriFaceDie_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_YuriFaceDie_rgba16[] = {
	#include "Yuri/YuriFaceDie.rgba16.inc.c"
};

Gfx Yuri_wing_2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_wing_2_rgba16[] = {
	#include "Yuri/wing_2.rgba16.inc.c"
};

Gfx Yuri_wing1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_wing1_rgba16[] = {
	#include "Yuri/wing1.rgba16.inc.c"
};

Gfx Yuri_Metal_Shade_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_Metal_Shade_rgba16_rgba16[] = {
	#include "Yuri/Metal_Shade.rgba16.inc.c"
};

Gfx Yuri_Metal_Light_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_Metal_Light_rgba16_rgba16[] = {
	#include "Yuri/Metal_Light.rgba16.inc.c"
};

Gfx Yuri_custom_mario_metal_wing_tip_shade_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_custom_mario_metal_wing_tip_shade_rgba16[] = {
	#include "Yuri/custom_mario_metal_wing_tip_shade.rgba16.inc.c"
};

Gfx Yuri_custom_mario_metal_wing_tip_light_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_custom_mario_metal_wing_tip_light_rgba16[] = {
	#include "Yuri/custom_mario_metal_wing_tip_light.rgba16.inc.c"
};

Gfx Yuri_custom_mario_metal_wing_shade_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_custom_mario_metal_wing_shade_rgba16[] = {
	#include "Yuri/custom_mario_metal_wing_shade.rgba16.inc.c"
};

Gfx Yuri_custom_mario_metal_wing_light_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Yuri_custom_mario_metal_wing_light_rgba16[] = {
	#include "Yuri/custom_mario_metal_wing_light.rgba16.inc.c"
};

