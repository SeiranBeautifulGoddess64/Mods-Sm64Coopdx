Gfx Sayori_Bow_Metal_Shade_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_Bow_Metal_Shade_rgba16_rgba16[] = {
	#include "Sayori/Metal_Shade.rgba16.inc.c"
};

Gfx Sayori_Bow_Metal_Light_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_Bow_Metal_Light_rgba16_rgba16[] = {
	#include "Sayori/Metal_Light.rgba16.inc.c"
};

