Gfx Sayori_shirt_ci4_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_shirt_ci4[] = {
	#include "Sayori/shirt.ci4.inc.c"
};

Gfx Sayori_shirt_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_shirt_pal_rgba16[] = {
	#include "Sayori/shirt.rgba16.pal"
};

Gfx Sayori_Button_ci4_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_Button_ci4[] = {
	#include "Sayori/Button.ci4.inc.c"
};

Gfx Sayori_Button_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_Button_pal_rgba16[] = {
	#include "Sayori/Button.rgba16.pal"
};

Gfx Sayori_ribbon_ci4_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_ribbon_ci4[] = {
	#include "Sayori/ribbon.ci4.inc.c"
};

Gfx Sayori_ribbon_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_ribbon_pal_rgba16[] = {
	#include "Sayori/ribbon.rgba16.pal"
};

Gfx Sayori_sayFace_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_sayFace_rgba16[] = {
	#include "Sayori/sayFace.rgba16.inc.c"
};

Gfx Sayori_sayFaceHalf_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_sayFaceHalf_rgba16[] = {
	#include "Sayori/sayFaceHalf.rgba16.inc.c"
};

Gfx Sayori_sayFaceClose_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_sayFaceClose_rgba16[] = {
	#include "Sayori/sayFaceClose.rgba16.inc.c"
};

Gfx Sayori_sayFaceDie_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_sayFaceDie_rgba16[] = {
	#include "Sayori/sayFaceDie.rgba16.inc.c"
};

Gfx Sayori_wing_2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_wing_2_rgba16[] = {
	#include "Sayori/wing_2.rgba16.inc.c"
};

Gfx Sayori_wing1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_wing1_rgba16[] = {
	#include "Sayori/wing1.rgba16.inc.c"
};

Gfx Sayori_bow_ci4_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_bow_ci4[] = {
	#include "Sayori/bow.ci4.inc.c"
};

Gfx Sayori_bow_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_bow_pal_rgba16[] = {
	#include "Sayori/bow.rgba16.pal"
};

Gfx Sayori_Metal_Shade_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_Metal_Shade_rgba16_rgba16[] = {
	#include "Sayori/Metal_Shade.rgba16.inc.c"
};

Gfx Sayori_Metal_Light_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_Metal_Light_rgba16_rgba16[] = {
	#include "Sayori/Metal_Light.rgba16.inc.c"
};

Gfx Sayori_custom_mario_metal_wing_tip_shade_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_custom_mario_metal_wing_tip_shade_rgba16[] = {
	#include "Sayori/custom_mario_metal_wing_tip_shade.rgba16.inc.c"
};

Gfx Sayori_custom_mario_metal_wing_tip_light_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_custom_mario_metal_wing_tip_light_rgba16[] = {
	#include "Sayori/custom_mario_metal_wing_tip_light.rgba16.inc.c"
};

Gfx Sayori_custom_mario_metal_wing_shade_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_custom_mario_metal_wing_shade_rgba16[] = {
	#include "Sayori/custom_mario_metal_wing_shade.rgba16.inc.c"
};

Gfx Sayori_custom_mario_metal_wing_light_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 Sayori_custom_mario_metal_wing_light_rgba16[] = {
	#include "Sayori/custom_mario_metal_wing_light.rgba16.inc.c"
};

